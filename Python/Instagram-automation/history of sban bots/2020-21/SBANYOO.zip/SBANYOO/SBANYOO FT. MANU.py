from selenium import webdriver
import time
from time import sleep
import random
from selenium.webdriver.common.keys import Keys
def mails():
    mail=""
    value=random.randint(5,15)
    dizio= {1: 'a', 3: 'c', 2: 'b', 5: 'e', 4: 'd', 7: 'g', 6: 'f', 9: 'i', 8: 'h', 11: 'k', 10: 'j', 13: 'm', 12: 'l', 15: 'o', 14: 'n', 17: 'q', 16: 'p', 19: 's', 18: 'r', 21: 'u', 20: 't', 23: 'w', 22: 'v', 25: 'y', 24: 'x', 26: 'z'}
    for i in range(0,value):
        x=dizio[random.randint(1,26)]
        mail+=x
    mail+="@gmail.com"
    return mail
def phones():
    number="+393"
    for i in range(0,9):
        number+=str(random.randint(0,9))
    return number
def mod1(nomis, user, text, maill, phonis, tempo, driver):
    sent = 1
    num = 0
    url = 'https://help.instagram.com/contact/606967319425038'
    ck = 0
    pausa = 0
    temp = tempo
    fact = False
    this = True
    while True:
        k = 0
        b = 1
        while k < scelta:

            try:
                tempo = temp
                driver.refresh()
                driver.delete_all_cookies()
                driver.get(url)
                try:
                    driver.find_element_by_xpath('/html/body/div/div[1]/div/div/div[2]/div[2]/button[2]').click()
                except:
                    ck = 0
                time.sleep(5)
                driver.find_element_by_id('649649255120112').send_keys(nomis[k])
                driver.find_element_by_id('1464214030500550').send_keys(user[k])
                driver.find_element_by_id('328991337275965').send_keys(maill[k])
                driver.find_element_by_id('602863763172693').send_keys(phonis[k])
                driver.find_element_by_id('709786765737601').send_keys(text)
                driver.find_element_by_xpath('//button[@class="_42ft _4jy0 _4jy4 _4jy1 selected _51sy"]').click()
                n = False
                sleep(2)
                try:
                    driver.find_element_by_xpath(
                        '//a[@class="_42ft _42fu layerConfirm uiOverlayButton selected _42g- _42gy"]').click()
                    print(sent, "MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")

                except:
                    n = False
                try:
                    driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/div/div/div[3]/div/a').click()
                    print("profilo: %d, sbannato!" % user[k])
                except:
                    n = False
                try:
                    driver.find_element_by_xpath(
                        "/html/body/div[2]/div[2]/div/div/div/div/div[3]/div/div/div[2]/div/a").click()
                    print('STAI ANDANDO TROPPO VELOCE')
                except:
                    n = False
                #print(sent, "MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")
                k += 1
                time.sleep(int(tempo))
            except:
                # print("da rimuovere")
                num -= 1
                # delete(num)
                fact = True
        print(sent, "cicli fatti")
        sleep(tempo)
        sent+=1
def mod2(nomis, user, maill, paese, tempo, driver):
    sent = 1
    while True:
        k = 0
        b = 1
        while k < scelta:
            try:
                driver.refresh()
                driver.delete_all_cookies()
                driver.get("https://help.instagram.com/contact/1652567838289083")
                time.sleep(5)
                try:
                    driver.find_element_by_xpath('/html/body/div/div[1]/div/div/div[2]/div[2]/button[2]').click()
                except:
                    ck = 0
                time.sleep(5)
                driver.find_element_by_xpath(
                    '//*[@id="SupportFormRow.904224879693114"]/div[3]/label[1]').click()
                idname = "495070633933955"
                iduser = "1489970557888767"
                idmail = "488955464552044"
                time.sleep(3)
                driver.find_element_by_id(idname).send_keys(nomis[k])
                sleep(0.5)
                driver.find_element_by_id(iduser).send_keys(user[k])
                sleep(0.5)
                driver.find_element_by_id(idmail).send_keys(maill[k])
                sleep(0.5)
                driver.execute_script("window.scrollTo(0, window.scrollY + 100)")
                sleep(0.5)
                try:
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                        paese)
                    sleep(1)
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                        Keys.RETURN)
                except:
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                        paese)
                    sleep(1)
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                        Keys.RETURN)
                sleep(2)
                try:
                    driver.find_element_by_xpath('/html/body/div/div/div[3]/div/div[2]/div/form/button').click()
                except:
                    driver.find_element_by_xpath('/html/body/div/div/div[3]/div/div[2]/div/form/button').click()
                sleep(2)
                try:
                    p = driver.find_element_by_xpath('/html/body/div[4]/div[2]/div/div/div/div/div[3]/div/div/div[2]/div/a').click()
                    print('errore sulla pagina %d' % user[k])
                except:
                    ck = 0
                try:
                    driver.find_element_by_xpath('/html/body/div[4]/div[2]/div/div/div/div[3]/div/a').click()
                    print(' %f sbannata!' % user[k])
                except:
                    ck = 0

                print(sent, "MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")
                sent += 1
                k += 1
                time.sleep(int(tempo))
            except:
                # print("da rimuovere")
                ck = 0
                # delete(num)
                fact = True
        print(sent -1 , 'cicli fatti ')
def mod3(nomis, user, text, maill, phonis, tempo, driver):
    sent = 1
    num = 0

    fact = False
    this = True

    while True:
        k = 0
        b = 0
        while k < scelta:
            try:
                driver.refresh()
                driver.delete_all_cookies()
                url = 'https://m.facebook.com/help/contact/606967319425038'
                driver.get(url)
                time.sleep(2)
                try:
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[7]/div[1]/div/div[2]/div/div[3]').click()
                except:
                    ck = 0
                time.sleep(4)
                try:
                    # driver.find_element_by_xpath('/html/body/div[1]/div/div[7]/div[1]/div/div[2]/div/div[3]/a').click()
                    driver.find_element_by_id('649649255120112').send_keys(nomis[k])
                    driver.find_element_by_id('1464214030500550').send_keys(user[k])
                    driver.find_element_by_id('328991337275965').send_keys(maill[k])
                    driver.find_element_by_id('602863763172693').send_keys(phonis[k])
                    driver.find_element_by_id('709786765737601').send_keys(text)
                    driver.find_element_by_xpath(
                        '/html/body/div[1]/div/div[3]/article/form/div[2]/button').click()
                    print(sent, "MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")
                    k +=1
                    b+=1

                except:
                    # print("da rimuovere")
                    num -= 1
                    # delete(num)
                    fact = True
            except:
                # print("da rimuovere")
                num -= 1
                # delete(num)
                fact = True
            print(sent, "CICLI DI MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")
            sent += 1
            time.sleep(int(tempo))
def mod4(nomis, user, text, maill, phonis, tempo, driver, paese):

    while True:
        sent = 1
        num = 0
        ck = 0
        pausa = 0
        temp = tempo
        fact = False
        this = True
        k = 0
        b = 1
        while k < scelta:
            try:
                url = 'https://help.instagram.com/contact/606967319425038'
                tempo = temp
                driver.refresh()
                driver.delete_all_cookies()
                driver.get(url)
                try:
                    driver.find_element_by_xpath('/html/body/div/div[1]/div/div/div[2]/div[2]/button[2]').click()
                except:
                    ck = 0
                time.sleep(5)
                driver.find_element_by_id('649649255120112').send_keys(nomis[k])
                driver.find_element_by_id('1464214030500550').send_keys(user[k])
                driver.find_element_by_id('328991337275965').send_keys(maill[k])
                driver.find_element_by_id('602863763172693').send_keys(phonis[k])
                driver.find_element_by_id('709786765737601').send_keys(text)
                driver.find_element_by_xpath('//button[@class="_42ft _4jy0 _4jy4 _4jy1 selected _51sy"]').click()
                sleep(5)
                n = False
                try:
                    driver.find_element_by_xpath(
                        '//a[@class="_42ft _42fu layerConfirm uiOverlayButton selected _42g- _42gy"]').click()
                    n = True
                except:
                    n = False
                try:
                    driver.find_element_by_xpath('/html/body/div[2]/div[2]/div/div/div/div[3]/div/a').click()
                    print("profilo: %d, sbannato!" % user[k])
                except:
                    n = False
                try:
                    driver.find_element_by_xpath(
                        "/html/body/div[2]/div[2]/div/div/div/div/div[3]/div/div/div[2]/div/a").click()
                    print('STAI ANDANDO TROPPO VELOCE, ORA FACCIAMO UNA PAUSA DI 5 MIN E POI RIPARTIAMO')
                    tempo = 5 * 60
                except:
                    n = False
                print('mod1 mandato')
                try:
                    driver.refresh()
                    driver.delete_all_cookies()
                    driver.get("https://help.instagram.com/contact/1652567838289083")
                    time.sleep(5)
                    try:
                        driver.find_element_by_xpath('/html/body/div/div[1]/div/div/div[2]/div[2]/button[2]').click()
                    except:
                        ck = 0
                    time.sleep(5)
                    driver.find_element_by_xpath(
                        '//*[@id="SupportFormRow.904224879693114"]/div[3]/label[1]').click()
                    idname = "495070633933955"
                    iduser = "1489970557888767"
                    idmail = "488955464552044"
                    time.sleep(4)
                    driver.find_element_by_id(idname).send_keys(nomis[k])
                    sleep(0.3)
                    driver.find_element_by_id(iduser).send_keys(user[k])
                    sleep(0.3)
                    driver.find_element_by_id(idmail).send_keys(maill[k])
                    sleep(0.3)
                    driver.execute_script("window.scrollTo(0, window.scrollY + 100)")
                    sleep(0.3)
                    try:
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                            paese)
                        sleep(1)
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                            Keys.RETURN)
                    except:
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                            paese)
                        sleep(1)
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[3]/div/div[2]/div/form/div[6]/div[2]/div/div/input').send_keys(
                            Keys.RETURN)
                    sleep(2)

                    driver.find_element_by_xpath('/html/body/div/div/div[3]/div/div[2]/div/form/button').click()
                except:
                    # print("da rimuovere")
                    num -= 1
                    # delete(num)
                    fact = True
                print('mod2 mandato')
                try:
                    driver.refresh()
                    driver.delete_all_cookies()
                    url = 'https://m.facebook.com/help/contact/606967319425038'
                    driver.get(url)
                    time.sleep(2)
                    try:
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[7]/div[1]/div/div[2]/div/div[3]').click()
                    except:
                        ck = 0
                    time.sleep(4)
                    try:
                        # driver.find_element_by_xpath('/html/body/div[1]/div/div[7]/div[1]/div/div[2]/div/div[3]/a').click()
                        driver.find_element_by_id('649649255120112').send_keys(nomis[k])
                        driver.find_element_by_id('1464214030500550').send_keys(user[k])
                        driver.find_element_by_id('328991337275965').send_keys(maill[k])
                        driver.find_element_by_id('602863763172693').send_keys(phonis[k])
                        driver.find_element_by_id('709786765737601').send_keys(text)
                        driver.find_element_by_xpath(
                            '/html/body/div[1]/div/div[3]/article/form/div[2]/button').click()
                    except:
                        # print("da rimuovere")
                        num -= 1
                        # delete(num)
                        fact = True
                except:
                    # print("da rimuovere")
                    num -= 1
                    # delete(num)
                    fact = True
                print(sent, "CICLO DI MODULI INVIATI PER", user[k], "ORA C'E' UNA PAUSA DI", tempo, "SECONDI")
                k += 1
                time.sleep(int(tempo))
            except:
                # print("da rimuovere")
                num -= 1
                # delete(num)
                fact = True
        print(sent, " CICLI DI MODULI SU TUTTE LE PAGE FATTO")
        sent += 1
if __name__=="__main__":
    sc1 = int(input("- CHE SISTEMA OPERATIVO USI: \n - MAC(1) \n - WIN(2): "))
    if sc1 == 1:
        drives = "/users/chromedriver"
    if sc1 == 2:
        drives = "chromedriver.exe"
    nomis = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
            28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
            54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 62, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
            80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
    user = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
            28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
            54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 62, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
            80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
    maill = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
            28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
            54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 62, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
            80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
    phonis = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
            28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
            54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 62, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
            80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
    print('---------------------------------------------------------------------------------------------\nREVISON TEAM\n---------------------------------------------------------------------------------------------')
    print("BOT DI LATRACHYOO")
    print('---------------------------------------------------------------------------------------------\nPrivate version:  sviluped by Karim latrach, phone: +393755332434 email: latrach234@gmail.com\n---------------------------------------------------------------------------------------------\n ')
    modulo = str(input(" => INSERISCI IL TIPO DI MODULO CHE VUOI MANDARE:\n => per mod1 digitare (1)\n => per mod2 digitare (2)\n => per moduli facebook digitare (3): \n => per tutti i moduli insieme (4):"))
    k = 0
    b = 1
    if modulo == "1":
        scelta = int(input(" - QUANTE PAGINE VUOI SBANNARE: (MAX 100 PROFILI): "))
        while k < scelta:
            print('\n\n -- PROFILO %d --\n\n' % b)
            username = input(
                " => Ora inserisci l'username dell' account n. %d da sbannare es: spaccianotty => " % b)
            nome = input(" => Inserisci nome e cognome spaziati per la page n. %d:=> " % b)
            user[k] = username
            nomis[k] = nome
            choice = input(" => SCEGLI PER IL PROFILO n: %d : \n - MAIL RANDOM(1)\n - MAIL PERSONALE(2): " % b)
            mail = ""
            if choice == "1":
                maill[k] = mails()
            if choice == "2":
                mail = input(" => inserisci mail :")
                maill[k] = mail
            choiceN = input(
                " => SCEGLI PER IL PROFILO n: %d: \n - NUMERO RANDOM(1)\n - NUMERO PERSONALE(2): " % b)
            phone = ""
            if choiceN == "1":
                phonis[k] = phones()
            if choiceN == "2":
                phone = input(" => inserisci numero di telefono ")
                phonis[k] = phone
            k += 1
            b += 1
        text = input(" => Ora inserisci la motivazione per lo sban => ")
        tempo = int(input(" => PAUSA IN SECONDI: "))
        print(" => BENE, IL BOT E' PRONTO PER INZIARE A MANDARE MODULI VIA LINK MOD1 PER SBANNARE LE PAGE" )
        print("")
        print("")
        cr = webdriver.ChromeOptions()
        cr.add_argument("--incognito")
        driver = webdriver.Chrome(drives, options=cr)
        mod1(nomis, user, text, maill, phonis, tempo, driver)
    if modulo == "2":
        print("\n\n\nAUTOMA PER MODULI MOD2 AVVIATO CORETTAMENTE! \n\n\n")
        scelta = int(input(" - QUANTE PAGINE VUOI SBANNARE: (MAX 100 PROFILI): "))
        while k < scelta:
            print('\n\n -- PROFILO %d --\n\n' % b)
            username = input(
                " => Ora inserisci l'username dell' account n. %d da sbannare es: spaccianotty => " % b)
            nome = input(" => Inserisci nome e cognome spaziati per la page n. %d:=> " % b)
            user[k] = username
            nomis[k] = nome
            choice = input(" => SCEGLI PER IL PROFILO n: %d : \n - MAIL RANDOM(1)\n - MAIL PERSONALE(2): " % b)
            mail = ""
            if choice == "1":
                maill[k] = mails()
            if choice == "2":
                mail = input(" => inserisci mail :")
                maill[k] = mail
            k +=1
            b +=1
        paese = str(input(" => inserisci il paese: "))
        tempo = int(input(" => PAUSA IN SECONDI: "))
        print("AVVIO BOT")
        cr = webdriver.ChromeOptions()
        cr.add_argument("--incognito")
        driver = webdriver.Chrome(drives, options=cr)
        mod2(nomis, user, maill, paese, tempo, driver)
        #print("momentaneamente non disponibile")
        #sleep(5)
        #quit()
    if modulo == "3":
        scelta = int(input(" - QUANTE PAGINE VUOI SBANNARE: (MAX 100 PROFILI): "))
        while k < scelta:
            print('\n\n -- PROFILO %d --\n\n' % b)
            username = input(
                " => Ora inserisci l'username dell' account n. %d da sbannare es: spaccianotty => " % b)
            nome = input(" => Inserisci nome e cognome spaziati per la page n. %d:=> " % b)
            user[k] = username
            nomis[k] = nome
            choice = input(" => SCEGLI PER IL PROFILO n: %d : \n - MAIL RANDOM(1)\n - MAIL PERSONALE(2): " % b)
            mail = ""
            if choice == "1":
                maill[k] = mails()
            if choice == "2":
                mail = input(" => inserisci mail :")
                maill[k] = mail
            choiceN = input(
                " => SCEGLI PER IL PROFILO n: %d: \n - NUMERO RANDOM(1)\n - NUMERO PERSONALE(2): " % b)
            phone = ""
            if choiceN == "2":
                phone = input(" => inserisci numero di telefono ")
                phonis[k] = phone
            if choiceN == "1":
                phonis[k] = phones()
            k += 1
            b += 1
        text = input(" => Ora inserisci la motivazione per lo sban => ")
        tempo = int(input(" => PAUSA IN SECONDI: "))
        print(" => BENE, IL BOT E' PRONTO PER INZIARE A MANDARE MODULI VIA LINK MOD1 PER SBANNARE LE PAGE")
        print("")
        print("")
        cr = webdriver.ChromeOptions()
        cr.add_argument("--incognito")
        driver = webdriver.Chrome(drives, options=cr)
        mod3(nomis, user, text, maill, phonis, tempo, driver)
    if modulo == "4":
        scelta = int(input(" - QUANTE PAGINE VUOI SBANNARE: (MAX 100 PROFILI): "))
        while k < scelta:
            print('\n\n -- PROFILO %d --\n\n' %b)
            username = input(
                " => Ora inserisci l'username dell' account n. %d da sbannare es: spaccianotty => " % b)
            nome = input(" => Inserisci nome e cognome spaziati per la page n. %d:=> " %b)
            user[k] = username
            nomis[k] = nome
            choice = input(" => SCEGLI PER IL PROFILO n: %d : \n - MAIL RANDOM(1)\n - MAIL PERSONALE(2): " % b)
            mail = ""
            if choice == "1":
                maill[k] = mails()
            if choice == "2":
                mail = input(" => inserisci mail :")
                maill[k] = mail
            choiceN = input(
                " => SCEGLI PER IL PROFILO n: %d: \n - NUMERO RANDOM(1)\n - NUMERO PERSONALE(2): " % b)
            phone = ""
            if choiceN == "1":
                phonis[k] = phones()
            if choiceN == "2":
                phone = input(" => inserisci numero di telefono ")
                phonis[k] = phone
            k += 1
            b += 1
        paese = str(input(" => inserisci il paese: "))
        text = input(" => Ora inserisci la motivazione per lo sban => ")
        tempo = int(input(" => PAUSA IN SECONDI: "))
        cr = webdriver.ChromeOptions()
        cr.add_argument("--incognito")
        driver = webdriver.Chrome(drives, options=cr)
        mod4(nomis, user, text, maill, phonis, tempo, driver, paese)