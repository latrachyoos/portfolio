@Tommaso Vilotto 
@03/18/2020

WINDOWS GUIDE 

First of all install python on yout pc -->  https://www.python.org/downloads/

then open cmd in this folder and type:>

python get-pip.py
pip install selenium
pip install PyWIn32
pip install wmi
python -m pip install --upgrade pip command

then you have to put the chromedriver.exe that you'll find in the "driver" fold in your system PATH, watch a tutorial 
on youtube if difficult, "HOW TO SEARCH PYTHON PATH FOLDER IN WINDOWS"
