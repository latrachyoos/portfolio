#developed by @Tommaso Vilotto for personal use
#06/29/2020 
#follow me on ig @tommyvilo and @itagliano.degradato
from selenium import webdriver
import time
import random
import string
import os
from selenium.webdriver.chrome.options import Options
import sys
from selenium.webdriver.common.keys import Keys
#boolean ran= True;

def getMail():

    mail=""
    value=random.randint(5,15)
    dizio= {1: 'a', 3: 'c', 2: 'b', 5: 'e', 4: 'd', 7: 'g', 6: 'f', 9: 'i', 8: 'h', 11: 'k', 10: 'j', 13: 'm', 12: 'l', 15: 'o', 14: 'n', 17: 'q', 16: 'p', 19: 's', 18: 'r', 21: 'u', 20: 't', 23: 'w', 22: 'v', 25: 'y', 24: 'x', 26: 'z'}
    for i in range(0,value):
        x=dizio[random.randint(1,26)]
        mail+=x
    mail+="@gmail.com"
    return mail 


def sendRequest(name,username,mail,paese,tempo):

        sent=0
        num=0

        print ("REQUESTS SENT: ",sent)
        driver = webdriver.Chrome()
        #name='Tommaso Vilotto'
        #username='itagliano.degradato'
       
        url = 'https://help.instagram.com/contact/1652567838289083'
        ck=(random.randint(1,3))
        fact=False
        while True:
            driver.get(url)
            try:
                t=time.perf_counter()
                time.sleep(2)
                driver.find_element_by_xpath('//*[@id="SupportFormRow.904224879693114"]/div[3]/label[1]').click()
                time.sleep(4)
                driver.find_element_by_id('904224879693114.1').send_keys(name)
                driver.find_element_by_id('495070633933955').send_keys(name)
                driver.find_element_by_id('1489970557888767').send_keys(username)
                driver.find_element_by_id('488955464552044').send_keys(mail)
                try:
                    driver.find_element_by_id('u_0_e').send_keys(paese)
                    driver.find_element_by_id('u_0_e').send_keys(Keys.RETURN)
                except:
                    driver.find_element_by_id('u_0_c').send_keys(paese)
                    driver.find_element_by_id('u_0_c').send_keys(Keys.RETURN)
                
                driver.find_element_by_xpath('//button[@class="_42ft _4jy0 _4jy4 _4jy1 selected _51sy"]').click()
                    
                try:
                    driver.find_element_by_xpath('//button[@class="_42ft _4jy0 _4jy4 _4jy1 selected _51sy"]').click()
                except:
                    ck=0
                                                                
                driver.find_element_by_xpath('//button[@class="_42ft _4jy0 _4jy4 _4jy1 selected _51sy"]').click()
                #driver.find_element_by_xpath('//button[@class="text').click()  
                t1=time.perf_counter()
                sent+=1
                
                print ("REQUESTS SENT: ",sent)
                time.sleep(tempo-(t1-t))
                
            except:
 
                fact=True


if __name__=="__main__":

    nome= input("Inserisci nome e cognome spaziati es: Tommaso Vilotto ")
    username= input ("Inserire username account es: itagliano.degradato ")
    #choice= input("SCEGLI: \n - MAIL RANDOM(1)\n - MAIL PERSONALI(2): ")
    #if choice=="1":
     #   mail = getMail()
    #else:
    mail = input("Inserisci inserisci mail valida: ")
    paese= input("Inserisci paese es: Italia ")
    tempo= int(input("Inserisci tempo in secondi tra un modulo e l'altro "))
    print("Verranno utilizzate mail e numeri di telefoni diversi per ogni modulo inviato! \n")
    sendRequest(nome,username,mail,paese,tempo)

